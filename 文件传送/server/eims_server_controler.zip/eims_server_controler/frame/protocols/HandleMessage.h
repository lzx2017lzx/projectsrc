#ifndef EIMS_HANDLEMESSAGE_H
#define EIMS_HANDLEMESSAGE_H

#include <iostream>
#include <fstream>

#include "Message.h"
#include "../common/Common.h"
#include "../../logic/Logic.h"
#include "../debug/eims_debug.h"

using namespace eims::common;

namespace eims
{
namespace protocols
{
class CHandleMessage : public CMessage
{
public:
	CHandleMessage();
	~CHandleMessage();
    char* HandleMessage(char* input, size_t len, string remote_ip, size_t* result_len);

private:
    //LuaOper *m_lua_oper_;
    Logic* m_logic_;

private:
	char* GeneralClientInfo(const char * msg, size_t len, size_t* outlen);
	char* FormatReturnMessage(char* messagecontent, unsigned int contentlen, size_t* retlen);
	char* GetErrorMessage(xml_oper* p_xml, size_t* outlen, string errlev);
};
}
}
#endif
