
#include "net_session.h"

namespace eims
{
namespace network
{

Session::Session(boost::asio::io_service& io_service)
    : socket_(io_service)
{

}

Session::~Session()
{
    socket_.close();
}

boost::asio::ip::tcp::socket& Session::socket()
{
    return socket_;
}

void Session::start()
{
    data_ = new char[4];

    boost::asio::async_read(socket_,
                            boost::asio::buffer(data_, 4),
                            boost::bind(&Session::handle_read_first, this,
                                        boost::asio::placeholders::error,
                                        boost::asio::placeholders::bytes_transferred));
}
void Session::handle_read_first(const boost::system::error_code& error, size_t bytes_transferred)
{
    if (error)
    {
        string log = "Handle read first failed. reason is :" + error.message();
        Common::logger->write_log(log, eLogLv.INFO);
        if (data_ != NULL)  delete[] data_;
        data_ = NULL;
        delete this;

        return;
    }

    int* plen = (int*)data_;

    if (*plen < 1)
    {
        if (data_ != NULL)  delete[] data_;
        data_ = NULL;
        delete this;

        return;
    }

    int len = *plen;
    if (data_ != NULL)  delete[] data_;
    data_ = NULL;

    //前四个字节表示的长度超长，异常消息，可能危害服务器。关闭掉连接
    if( (unsigned int)len > MessageMaxLength)
    {
    	delete this;
    	return;
    }
    data_ = new char[len];

    boost::asio::async_read(socket_,
                            boost::asio::buffer(data_, len),
                            boost::bind(&Session::handle_read_second, this,
                                        boost::asio::placeholders::error,
                                        boost::asio::placeholders::bytes_transferred));
}

void Session::handle_read_second(const boost::system::error_code& error, size_t bytes_transferred)
{
    if (error)
    {
        string log = "Handle read second failed. reason is :" + error.message();
        Common::logger->write_log(log, eLogLv.INFO);
        if (data_ != NULL)  delete[] data_;
        data_ = NULL;
        delete this;

        return;
    }

    result_len = 0;

    try
    {
        result_data = hm.HandleMessage(data_, bytes_transferred, socket_.remote_endpoint().address().to_string(), &result_len);
    }
    catch (const std::exception& e)
    {
        string log = "Handle message failed. reason is :";
        log.append(e.what());
        Common::logger->write_log(log, eLogLv.INFO);

        if (data_ != NULL)
			delete[] data_;
        data_ = NULL;

        if(result_data != NULL)
			delete[] result_data;
        result_data = NULL;

        delete this;

        return;
    }

    if (data_ != NULL)
		delete[] data_;
    data_ = NULL;

    boost::asio::async_write(socket_,
                             boost::asio::buffer(&result_len, 4),
                             boost::bind(&Session::handle_write_second, this,
                                         boost::asio::placeholders::error,
										 boost::asio::placeholders::bytes_transferred));
}
void Session::handle_write_second(const boost::system::error_code& error, size_t bytes_transferred)
{
	boost::asio::async_write(socket_,
                             boost::asio::buffer(result_data, result_len),
                             boost::bind(&Session::handle_write, this,
                                         boost::asio::placeholders::error));
}
void Session::handle_write(const boost::system::error_code& error)
{
    if (result_data != NULL)
		delete[] result_data;
    result_data = NULL;

    if (!error)
    {
        // keep read header
        Session::start();
    }
    else
    {
    	string log = "handle_write failed. reason is :" + error.message();
		Common::logger->write_log(log, eLogLv.INFO);
        delete this;
    }

}


// No new asynchronous operations are started. This means that all shared_ptr
// references to the Session object will disappear and the object will be
// destroyed automatically after this handler returns. The Session class's
// destructor closes the socket.

} // namespace network
} // namespace eims



