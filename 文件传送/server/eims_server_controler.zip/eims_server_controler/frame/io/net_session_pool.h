
#ifndef __EIMS_SESSION_POOL_H_INC__
#define __EIMS_SESSION_POOL_H_INC__

#include <boost/asio.hpp>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>

namespace eims
{
namespace network
{

//
//  class SessionPool
//
class SessionPool
  : private boost::noncopyable
{
public:
  explicit SessionPool(std::size_t pool_size);

  void run();

  void stop();

  boost::asio::io_service& get_io_service();

private:
  typedef boost::shared_ptr<boost::asio::io_service> io_service_ptr;
  typedef boost::shared_ptr<boost::asio::io_service::work> work_ptr;

  std::vector<io_service_ptr> m_io_services;

  std::vector<work_ptr> m_work;

  std::size_t m_next_io_service;
};

} // namespace network
} // namespace eims

#endif



