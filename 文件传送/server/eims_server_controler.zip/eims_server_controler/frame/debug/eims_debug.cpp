 #include "eims_debug.h"

eims_debug::eims_debug()
{
	//ctor
}

eims_debug::~eims_debug()
{
	//dtor
}

void eims_debug::print_time_now()
{
	struct timeval tv;
    gettimeofday(&tv,NULL);
    printf("time now :%ld\n",tv.tv_sec * 1000 + tv.tv_usec / 1000);
}
