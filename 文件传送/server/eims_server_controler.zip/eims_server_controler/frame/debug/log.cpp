#include "log.h"

namespace eims
{
namespace debug
{

map<unsigned long int, ShareList*> Logger::queues;

Logger* Logger::m_self_ = NULL;
sem_t Logger::rw_sem;
pthread_mutex_t Logger::create_locker;
Logger::Logger()
{
    //ctor
    pthread_mutex_init(&create_locker, 0);
    m_log_sublevel = eLogLv.INFO;
    sem_init(&rw_sem, 0, 0);
}
Logger* Logger::get_singleton()
{
	if(m_self_ == NULL)
	{
		m_self_ = new Logger();
	}
	return m_self_;
}
Logger::~Logger()
{
	for(map<unsigned long int, ShareList*>::iterator it = queues.begin(); it != queues.end(); it++)
	{
		delete it->second;
	}
	queues.clear();
    sem_destroy(&rw_sem);
    pthread_mutex_destroy(&create_locker);
}
ShareList::ShareList()
{
	header = NULL;
    curnode = NULL;
}
ShareList::~ShareList()
{
	if(header != curnode)
	{
		if(header != NULL)
		{
			delete header;
			header = NULL;
		}
		if(curnode != NULL)
		{
			delete curnode;
			curnode = NULL;
		}
	}
	else
	{
		if(header != NULL)
			delete header;
		header = NULL;
	}
}

void ShareList::put_back(string data, int lv)
{
    NODE* n = new NODE;
    if(!n) { return; }
    n->data_ = new char[data.size()];
    if(!n->data_) { delete n; n = NULL; return; }
    memcpy(n->data_, data.c_str(), data.size());
    n->len = data.size();
    n->i = 0;
    n->lev = lv;
    n->next_ = NULL;
    if(curnode != NULL)
    {
        curnode->next_ = n;
        curnode = n;
    }
    else
        curnode = n;

    if(header == NULL)
        header = n;
}

void ShareList::get_front(string& content, int &lev)
{
    if(header == NULL)
        return ;
    if(header->i == 0)
    {
        content.append(header->data_, header->len);
        header->i = 1;
        lev = header->lev;
    }
    if(header->next_ != NULL)
    {
        NODE* t = header->next_;
        delete header;
        header = t;
    }
}

void Logger::write_log(string log, int lev = eLogLv.INFO)
{
    unsigned long int pid = pthread_self();
	_get_queue(pid)->put_back(log, lev);
	sem_post(&rw_sem);
}

void Logger::get_one_log_ex(vector<LogContent>& logs)
{
	sem_wait(&rw_sem);
	for(map<unsigned long int, ShareList*>::iterator it = queues.begin(); it != queues.end(); it++)
	{
		LogContent log;
		it->second->get_front(log.ctx, log.level);
		if(log.ctx == "")
			continue;
		log.tid = it->first;
		logs.push_back(log);
	}
}

void* Self_manager_func_ex(void* p)
{
	Logger* loger = (Logger*)p;
	string sw = "";
	string sk = "";
	ofstream ofile;
	ofile.open(loger->m_log_path_.c_str(), ofstream::app);
	if(ofile.fail())
	{
		cout<<"Warn: log file open failed .logger will not write to file"<<endl;
	}
	vector<LogContent> vlogs;
	while(loger->m_isrun_)
	{
		loger->get_one_log_ex(vlogs);
		if(vlogs.size() <= 0) continue;
		for(vector<LogContent>::iterator it = vlogs.begin(); it != vlogs.end(); it++)
		{
			string logctx = "";
			logctx.append(TimeToString()).append(" tid: ").append(longlong2str(it->tid)).append(": [").append(longlong2str(it->level)).append("]: ").append(it->ctx).append("\n");
			if(it->level <= LOGWRITELEVEL)
			{
				sw += logctx;
			}
			if(it->level <= loger->m_log_sublevel)
			{
				sk += logctx;
			}
		}
		//write to file
		if(ofile.is_open() && sw != "")
		{
			ofile<<sw;
			ofile.flush();
		}
		if(LOGPRINT != 0)
		{
			printf("%s\n", sw.c_str());
		}
		//日志订阅开关打开，允许订阅服务终端的日志
		if(LOGSUBSCRIBE == 1)
		{
			loger->m_udp_wr_.write_to_sock(sk);
		}
		sw.clear();
		sk.clear();
		vlogs.clear();
	}
	ofile.close();
	return NULL;
}

bool Logger::initialize(string path)
{
	if(LOGSUBSCRIBE == 1)
	{
		if(!m_udp_wr_.initial(SUBSCRIBEPORT))
		{
			m_udp_wr_.stop();
			printf("log subscribe open failed。\n");
		}
	}
	m_log_path_ = path;
	m_isrun_ = true;
	pthread_create(&m_sel_mgr_thread_, NULL, Self_manager_func_ex, this);
	return true;
}
void Logger::quit()
{
	if(LOGSUBSCRIBE == 1)
		m_udp_wr_.stop();
	m_isrun_ = false;
	sem_post(&rw_sem);
	sleep(1);
	pthread_join(m_sel_mgr_thread_, 0);
}

ShareList* Logger::_get_queue(unsigned long int id)
{
	if(queues[id] == NULL)
	{
		pthread_mutex_lock(&create_locker);
		queues[id] = new ShareList();
		pthread_mutex_unlock(&create_locker);
	}
	return queues[id];
}
}
}
