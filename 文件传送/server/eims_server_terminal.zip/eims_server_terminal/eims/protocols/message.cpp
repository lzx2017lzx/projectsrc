#include "message.h"

#define USE_BOOST
namespace eims
{
namespace protocols
{


}
}
