#!/bin/sh

echo "########### start building ... ############"

	g++ main.cpp frame/io/udp/*.cpp frame/common/*.cpp frame/db/*.cpp frame/debug/*.cpp frame/io/*.cpp frame/protocols/*.cpp frame/xml/*.cpp logic/*.cpp -o  bin/eims_server_controler -Ipublic/boost/include -Ipublic/mysql/include -Ipublic/shove/include -Lpublic/boost/lib -Lpublic/mysql/lib -Lpublic/shove/lib -lboost_thread -lboost_system -lmysqlclient_r -lshove

echo "########### build finished .   ############"
