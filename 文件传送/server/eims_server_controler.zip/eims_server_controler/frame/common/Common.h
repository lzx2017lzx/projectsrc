#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED

#include <boost/unordered_map.hpp>
#include <sys/time.h>
#include <configure_file.h>
#include <Utility.h>
#include "Consts.h"
#include "../debug/log.h"
#include "../xml/xml_oper.h"
#include "../db/mysql_cnt.h"

//开启DEBUG模式
//#define DEBUG
//开启日志
//#define LOG


using namespace std;
using namespace boost;
using namespace shove;
using namespace eims::db;
using namespace eims::debug;

namespace eims
{
namespace common
{
static const string SYSTEM_KEY = "qwertyu1qwertyu3qwertyu6";
static unordered_map<unsigned long int, xml_oper*> g_xml_parsers;
static unordered_map<unsigned long int, mysql_cnt*> g_db_opers;

class Common
{

public:

	//加载配置项
	static void loadconfig();

	static xml_oper* xml_parser_grap(unsigned long int id);
	static mysql_cnt* sql_oper_grab(unsigned long int id);
	static Logger* logger;

};

}
}
#endif // COMMON_H_INCLUDED
