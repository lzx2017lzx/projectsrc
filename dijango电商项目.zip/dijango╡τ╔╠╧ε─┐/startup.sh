
python manage.py 0.0.0.0:8100
