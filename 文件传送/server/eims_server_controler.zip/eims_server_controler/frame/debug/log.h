#ifndef LOG_H
#define LOG_H

#include <map>
#include <vector>
#include <string>
#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>
#include <sstream>
#include <fstream>
//#include "../security/shove/convert.h"
#include "../io/udp/net_udp_writer.h"
#include "../common/Consts.h"
#include "../common/meta.h"

using namespace std;
//using namespace shove;
using namespace eims::network;
using namespace eims::meta;

namespace eims
{
	namespace debug
	{
		///日志等级枚举
		extern struct STULOGLEVEL
		{
			enum LOGLEVEL { FATAL = 1, ERROR, WARN, DEBUG, INFO, RUNTIME } ;
		} eLogLv;

		///数据缓存链表（单向链表）的节点
		struct NODE
		{
			///数据是否已经被取走的标识
			int i;
			///节点数据内容的长度
			int len;
			///节点（日志）的等级
			int lev;
			///节点的数据内容
			char* data_;
			///下一个节点
			NODE* next_;
			///构造
			NODE()
			{
				lev = 6; data_ = NULL; next_ = NULL;
			};
			///构造
			~NODE()
			{
				if(data_ != NULL) delete[] data_; data_ = NULL;
			};
		};

		///数据缓存链表
		class ShareList
		{
			///链表头
			NODE* header;
			///链表尾
			NODE* curnode;
		public:
			ShareList();
			~ShareList();
			///向链表中添加节点，只需要传入日志的内容及等级即可，方法会生成节点，并添加到链表中
			void put_back(string data, int lv);
			///获取链表头上的节点的内容，并删除头节点
			void get_front(string& content, int &lev);
		};

		///日志内容
		struct LogContent
		{
			///日志内容
			string ctx;
			///日志等级
			int level;
			///生成日志的线程ID
			long long tid;
		};

		///日志类
		class Logger
		{
			///互斥锁
			static pthread_mutex_t create_locker;

		private:
			///各线程的日志队列
			static map<unsigned long int, ShareList*> queues;
			///信号量
			static sem_t rw_sem;
			///日志管理线程
			pthread_t m_sel_mgr_thread_;
			///日志的单例指针
			static Logger* m_self_;

		public:
			~Logger();
			///初始化。参数为日志路径
			bool initialize(string path);
			///写日志。参数分别为日志内容，日志等级
			void write_log(string log, int lev);
			///向缓存队列中获取日志
			void get_one_log_ex(vector<LogContent>& logs);
			///关闭日志
			void quit();
			///创建日志类的单例
			static Logger* get_singleton();

		private:
			///获取线程对应的日志队列
			ShareList* _get_queue(unsigned long int id);
			Logger();

		public:
			///日志运行标志
			bool m_isrun_;
			///日志路径
			string m_log_path_;
			///UDP订阅的IO对象
			UdpWritter m_udp_wr_;
			///日志订阅等级
			int m_log_sublevel;
		};
	}
}

#endif // LOG_H
