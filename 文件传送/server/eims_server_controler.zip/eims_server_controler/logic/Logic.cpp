 #include "Logic.h"

Logic::Logic()
{
	//ctor
}

Logic::~Logic()
{
	//dtor
}

void Logic::GetBestServer(xml_oper* pxml, mysql_cnt* psql)
{
	stringstream ss;

	string remoteip = pxml->get_node_value("data/ip");
	string id = pxml->get_node_value("id");
	string ver = pxml->get_node_value("ver");
	pxml->load_xml_data(response_message, "message");
	unsigned int ip_num = IPToValue(remoteip);
	string ip_num_str = "";
	ss.clear();
	ss<<ip_num;
	ss>>ip_num_str;
	string ipselsql = "select province_id, oper_id from t_ip_info_mem where start_ip_num <= " + ip_num_str + " and end_ip_num >= " + ip_num_str;

	int db_result = psql->exe_sql(ipselsql.c_str());
	if(db_result != 0)
	{
		pxml->load_xml_data(response_message, "message");
		pxml->add_child_node("error_desc", "server_error", "data");
		pxml->set_node_value("errlev", "1");
		pxml->set_node_value("ver", ver);
		pxml->set_node_value("id", id);
		Common::logger->write_log("数据库执行错误，SQL语句为：" + ipselsql, eLogLv.ERROR);
		return;
	}
	if(psql->get_rows_count() <= 0)
	{
		///获取不到用户的位置
		///随机选择三台服务器
		string randselsql = "select `name`, ip, `port` from  t_servers order by rand() limit 3";
		db_result = psql->exe_sql(randselsql.c_str());
		if(db_result != 0)
		{
			pxml->load_xml_data(response_message, "message");
			pxml->add_child_node("error_desc", "server_error", "data");
			pxml->set_node_value("errlev", "1");
			pxml->set_node_value("ver", ver);
			pxml->set_node_value("id", id);
			Common::logger->write_log("数据库执行错误，SQL语句为：" + randselsql, eLogLv.ERROR);
			return;
		}
		int svrcount = psql->get_rows_count();
		pxml->add_child_node("servers", "", "data");
		for(int i = 0; i < svrcount; i++)
		{
			string s = "";
			ss.clear();
			ss<<i + 1;
			ss>>s;
			//pxml->add_child_node("servers", "", "data");
			pxml->add_child_node("server" + s, "", "data/servers");
			pxml->add_child_node("ip", psql->get_query_result(i, "ip"), "data/servers/server" + s);
			pxml->add_child_node("port", psql->get_query_result(i, "port"), "data/servers/server" + s);
			pxml->add_child_node("name", psql->get_query_result(i, "name"), "data/servers/server" + s);
		}
		pxml->set_node_value("ver", ver);
		pxml->set_node_value("id", id);
		pxml->set_node_value("errlev", "0");
		pxml->add_child_node("error_desc", "none", "data");
		return;
	}

	///查找用户所在区域最适合的服务器
	string provinceid = psql->get_query_result(0, "province_id");
	string svrselsql = "select distinct server_id, s.`name`, s.ip, s.`port` from t_service_area a left join t_servers s ";
	svrselsql += "on a.server_id = s.id where a.server_province = " + provinceid;
	db_result = psql->exe_sql(svrselsql.c_str());
	if(db_result != 0)
	{
		pxml->load_xml_data(response_message, "message");
		pxml->add_child_node("error_desc", "server_error", "data");
		pxml->set_node_value("errlev", "1");
		pxml->set_node_value("ver", ver);
		pxml->set_node_value("id", id);
		Common::logger->write_log("数据库执行错误，SQL语句为：" + svrselsql, eLogLv.ERROR);
		return;
	}
	int db_row_count = psql->get_rows_count();
	pxml->add_child_node("servers", "", "data");
	for(int i = 0; i < db_row_count; i++)
	{
		string s = "";
		ss.clear();
		ss<<i + 1;
		ss>>s;
		//pxml->add_child_node("servers", "", "data");
		pxml->add_child_node("server" + s, "", "data/servers");
		pxml->add_child_node("ip", psql->get_query_result(i, "ip"), "data/servers/server" + s);
		pxml->add_child_node("port", psql->get_query_result(i, "port"), "data/servers/server" + s);
		pxml->add_child_node("name", psql->get_query_result(i, "name"), "data/servers/server" + s);
	}

	///没有找到地区对应的服务器或者找到的数目少于3台
	if(db_row_count < 3)
	{
		///获取不到用户的位置
		///随机选择三台服务器
		string randselsql = "select `name`, ip, `port` from  t_servers order by rand() limit 3";
		db_result = psql->exe_sql(randselsql.c_str());
		if(db_result != 0)
		{
			pxml->load_xml_data(response_message, "message");
			pxml->add_child_node("error_desc", "server_error", "data");
			pxml->set_node_value("errlev", "1");
			pxml->set_node_value("ver", ver);
			pxml->set_node_value("id", id);
			Common::logger->write_log("数据库执行错误，SQL语句为：" + randselsql, eLogLv.ERROR);
			return;
		}
		int svrcount = psql->get_rows_count();
		/// 将随机查找出来的三台服务器填充到消息中，凑够三台
		for(int i = db_row_count; i < svrcount; i++)
		{
			string s = "";
			ss.clear();
			ss<<i + 1;
			ss>>s;
			//pxml->add_child_node("servers", "", "data");
			pxml->add_child_node("server" + s, "", "data/servers");
			pxml->add_child_node("ip", psql->get_query_result(i, "ip"), "data/servers/server" + s);
			pxml->add_child_node("port", psql->get_query_result(i, "port"), "data/servers/server" + s);
			pxml->add_child_node("name", psql->get_query_result(i, "name"), "data/servers/server" + s);
		}
		//pxml->add_child_node("error_desc", "none", "data");
	}
	pxml->set_node_value("errlev", "0");
	pxml->set_node_value("ver", ver);
	pxml->set_node_value("id", id);
	pxml->add_child_node("error_desc", "none", "data");
	return;
}
