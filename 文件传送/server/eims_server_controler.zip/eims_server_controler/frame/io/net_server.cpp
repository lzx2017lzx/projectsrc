#include "net_server.h"
#include <boost/bind.hpp>

namespace eims {
namespace network {


Server::Server(const std::string& address, const std::string& port,std::size_t m_io_service_poolsize)
    : m_io_service_pool(m_io_service_poolsize),
    m_signals(m_io_service_pool.get_io_service()),
    m_acceptor(m_io_service_pool.get_io_service()),
    m_current_accept_session(NULL)
{
    // Register to handle the signals that indicate when the Server should exit.
    // It is safe to register for the same signal multiple times in a program,
    // provided all registration for the specified signal is made through Asio.
    m_signals.add(SIGINT);
    m_signals.add(SIGTERM);
#if defined(SIGQUIT)
    m_signals.add(SIGQUIT);
#endif // defined(SIGQUIT)
    m_signals.async_wait(boost::bind(&Server::handle_stop, this));

    // Open the acceptor with the option to reuse the address (i.e. SO_REUSEADDR).
    boost::asio::ip::tcp::resolver resolver(m_acceptor.get_io_service());
    boost::asio::ip::tcp::resolver::query query(address, port);
    boost::asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);
    m_acceptor.open(endpoint.protocol());
    m_acceptor.set_option(boost::asio::ip::tcp::acceptor::reuse_address(false));
    m_acceptor.bind(endpoint);
    m_acceptor.listen();

    start_accept();
}

void Server::run()
{
    m_io_service_pool.run();
}

void Server::start_accept()
{
    m_current_accept_session = new Session(m_io_service_pool.get_io_service());

    m_acceptor.async_accept(m_current_accept_session->socket(),
    boost::bind(&Server::handle_accept, this,
    boost::asio::placeholders::error));
}

void Server::handle_accept(const boost::system::error_code& e)
{
    // if accept failed, the session's socket will be closed,
    // then session will delete itself.
    if (!e)
    {
        m_current_accept_session->start();
    }
    else
    {
    	string log = "Start to accept failed.reason is :" + e.message();
		//CUtilitys::WriteLog(DEBUG_FILE, log);
    }
    start_accept();
}

void Server::handle_stop()
{
    m_io_service_pool.stop();
}


} // namespace network
} // namespace eims
