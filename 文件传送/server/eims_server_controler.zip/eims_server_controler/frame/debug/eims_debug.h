 #ifndef EIMS_DEBUG_H
#define EIMS_DEBUG_H
#include <stdio.h>
#include <sys/time.h>


class eims_debug
{
	public:
		eims_debug();
		virtual ~eims_debug();

		static void print_time_now();
	protected:
	private:
};

#endif // EIMS_DEBUG_H
