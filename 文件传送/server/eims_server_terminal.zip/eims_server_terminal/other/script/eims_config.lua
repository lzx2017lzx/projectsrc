--------------------------------------------------
--
--	you can set some config in here
--
--------------------------------------------------


config = {}

config.open_visit_statistics = 0
config.open_log_record = 1
--others
config.script_path="../other/script/?.lua;"	--not used
config.message_check_span = 60
config.xny_res_url = "http://test-site.xiniuyun.com/resources"