#include "HandleMessage.h"

namespace eims
{
namespace protocols
{
CHandleMessage::CHandleMessage()
{
    //m_lua_oper_ = NULL;
    m_logic_ = new Logic;
}
CHandleMessage::~CHandleMessage()
{

}
char* CHandleMessage::HandleMessage(char* input, size_t len, string remote_ip, size_t* result_len)
{
    /////////////////////////////////////////////////////////////
    if(input == NULL)
    {
        return NULL;
    }
//#define DEBUG
#ifdef DEBUG
    printf("\nrecv data is :\n");
    for(int i = 0; i < len; i++)
    {
    	printf("%hhx ", input[i]);
    }
    printf("\n");
#endif

	string input_data = "";
	input_data.append(input, len);

    //���� XML����
	unsigned long int pid = pthread_self();
	xml_oper* xml_parser = Common::xml_parser_grap(pid);
	mysql_cnt* sql_oper = Common::sql_oper_grab(pid);
#ifdef DEBUG
	printf("\nRecv Xml Data is :%s\n", input_data.c_str());
#endif

	int parse_result = xml_parser->load_xml_data(input_data, "message");

	if(parse_result != 0)
	{
		char* ret_data = GetErrorMessage(xml_parser, result_len, "1");
#ifdef DEBUG
		printf("\nreturn error data is :");
		for(int i = 0; i < *result_len; i++)
		{
			printf("%hhx ", ret_data[i]);
		}
		printf("\n");
#endif
		xml_parser->clear_all_nodes();
		Common::logger->write_log("�ͻ��˵���Ϣ��XML����ʧ�ܡ�", eLogLv.ERROR);
		return ret_data;
	}
	string ins = xml_parser->get_node_value("instruction");
	xml_parser->add_child_node("ip", remote_ip, "data");
	if(ins != "101")
	{
		char* ret_data = GetErrorMessage(xml_parser, result_len, "1");
		xml_parser->clear_all_nodes();
		Common::logger->write_log("ָ��Ƿ���", eLogLv.INFO);
		return ret_data;
	}
	//�ڴ˴������ݿ��л�ȡ���������б���Ϣ
	m_logic_->GetBestServer(xml_parser, sql_oper);

	string servers_xml_info = xml_parser->create_xml_string();
	xml_parser->clear_all_nodes();

    //���ؽ��
    unsigned int xmllen = servers_xml_info.length();
	char* temp = new char[xmllen + 1];
	memset(temp, 0x0, xmllen + 1);
	memcpy(temp, servers_xml_info.c_str(), xmllen);

#ifdef DEBUG
	printf("\nreturn xml data is :%s", servers_xml_info.c_str());
#endif
    *result_len = xmllen;
    return temp;
}

char* CHandleMessage::GetErrorMessage(xml_oper* p_xml, size_t* outlen, string errlev)
{
	p_xml->load_xml_data(response_message, "message");
	p_xml->set_node_value("errlev", errlev);
	string s = p_xml->create_xml_string();
	char* temp = new char[s.length()];
	memcpy(temp, s.c_str(), s.length());
	*outlen = s.length();
	return temp;
}

////////////////////
//���ɿͻ��˱������Ϣ
char* CHandleMessage::GeneralClientInfo(const char * msg, size_t len, size_t* outlen)
{
	return NULL;
}

/////
char* CHandleMessage::FormatReturnMessage(char* messagecontent, unsigned int contentlen, size_t* retlen)
{
	return NULL;
}
}
}
