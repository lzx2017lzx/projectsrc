#ifndef __EIMS3_SERVER_H_INC__
#define __EIMS3_SERVER_H_INC__

#include <iostream>
#include <boost/asio.hpp>
#include <string>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include "net_session.h"
#include "net_session_pool.h"
//#include "../common/Utilitys.h"
//#include "../common/Consts.h"

using namespace std;
namespace eims
{
namespace network
{

//
//  class  TcpServer
//
class Server: private boost::noncopyable
{
public:
    explicit Server(const std::string& address, const std::string& port,std::size_t io_service_pool_size);

    void run();

private:
    void start_accept();

    void handle_accept(const boost::system::error_code& e);

    void handle_stop();


private:
    SessionPool m_io_service_pool;

    boost::asio::signal_set m_signals;

    boost::asio::ip::tcp::acceptor m_acceptor;

    Session* m_current_accept_session;
};

}

}

#endif
