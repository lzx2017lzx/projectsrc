#ifndef __EIMS_SESSION_H_INC__
#define __EIMS_SESSION_H_INC__

#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/array.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include "../protocols/HandleMessage.h"
#include "../common/Common.h"


using namespace eims::protocols;
using namespace eims::common;

namespace eims
{
namespace network
{

class Session
  : public boost::enable_shared_from_this<Session>,
    private boost::noncopyable
{
public:
  explicit Session(boost::asio::io_service& io_service);

  ~Session();

  boost::asio::ip::tcp::socket& socket();

  void start();

private:
     void handle_read_first(const boost::system::error_code& error, size_t bytes_transferred);
     void handle_read_second(const boost::system::error_code& error, size_t bytes_transferred);
     void handle_write_second(const boost::system::error_code& error, size_t bytes_transferred);
     void handle_write(const boost::system::error_code& error);

private:
	CHandleMessage hm;
    boost::asio::ip::tcp::socket socket_;
    char* data_;
    char* result_data;
    size_t result_len;
};

typedef boost::shared_ptr<Session> session_ptr;

} // namespace network
} // namespace eims

#endif
