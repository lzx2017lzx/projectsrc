#!/usr/bin/env python
import os
import sys

if __name__ == "__main__":
    manager.py runserver 0.0.0.0:8100
