#ifndef EIMS_MESSAGE_H
#define EIMS_MESSAGE_H

#include <iostream>
#include <fstream>
#include <string>

#include <Utility.h>

//#include "../../frame/common/Utilitys.h"
//#include "Parameter.h"

using namespace shove;
using namespace std;

namespace eims
{
namespace protocols
{
const char MessagePreFix[3] = { 0x01, 0x02, 0x03 };
const unsigned int ClientIDLength = 12;
static string response_message = "<message><id>0</id><ver>0</ver><errlev>0</errlev><instruction>0</instruction><sign>0</sign><data><error_desc></error_desc></data></message>";

static const size_t MessageMaxLength = 100000;


class CMessage
{

protected:
	virtual char* FormatReturnMessage(char* messagecontent, unsigned int contentlen, size_t* retlen) = 0;
};
}
}
#endif
