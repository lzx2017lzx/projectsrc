#include "global.h"
namespace eims
{
namespace global
{

	eims::debug::Logger* Global::logger = eims::debug::Logger::get_singleton();
	//RSA_Encry Global::_rsa;
}
}
