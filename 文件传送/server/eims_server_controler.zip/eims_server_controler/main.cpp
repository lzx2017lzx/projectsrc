#include <ctime>
#include <boost/asio.hpp>

#include "frame/common/Consts.h"
#include "frame/common/Common.h"
#include "frame/io/net_server.h"

using boost::asio::ip::tcp;
using namespace eims::db;
using namespace eims::common;


int main(int argc, char* argv[])
{
    // ��ʼ���������
    srand((unsigned int)time(NULL));

	Common::loadconfig();

	//��־���ʼ��
	if(!Common::logger->initialize(DEBUG_FILE))
	{
		printf("Warn: Logger initial failed.\n");
	}
	printf("eims_server_controler starting\n");
	Common::logger->write_log("eims_server_controler starting", eLogLv.INFO);

    string server_port = shove::convert::NumberToString<int>(HOST_PORT);
    eims::network::Server s(HOST_ADDRESS,server_port,MAXTHREADS);
    s.run();

    Common::logger->quit();
    delete Common::logger;

    return 0;
}
