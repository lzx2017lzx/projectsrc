#include "Common.h"

namespace eims
{
namespace common
{
	Logger* Common::logger = eims::debug::Logger::get_singleton();;

	xml_oper* Common::xml_parser_grap(unsigned long int id)
	{
#ifdef LOG
		if(g_xml_parsers.size() > (unsigned)MAXTHREADS)
		{
			//xml的指针数已经大于线程数量，有异常，可能有泄漏
			//记录日志
		}
#endif
		if(g_xml_parsers[id] == NULL)
		{
			g_xml_parsers[id] = new xml_oper;
			assert(g_xml_parsers[id] != NULL);
		}
		return g_xml_parsers[id];
	}
	mysql_cnt* Common::sql_oper_grab(unsigned long int id)
	{
#ifdef LOG
		if(g_db_opers.size() > (unsigned)MAXTHREADS)
		{
			//db连接的指针数已经大于线程数量，有异常，可能有泄漏
			//记录日志
		}
#endif
		if(g_db_opers[id] == NULL)
		{
			g_db_opers[id] = new mysql_cnt();
			assert(g_db_opers[id] != NULL);
			g_db_opers[id]->set_options(MYSQL_OPT_CONNECT_TIMEOUT, (void*)&DB_CONNECTTIMEOUT);
			g_db_opers[id]->set_options(MYSQL_OPT_READ_TIMEOUT, (void*)&DB_READTIMEOUT);
			g_db_opers[id]->set_options(MYSQL_OPT_WRITE_TIMEOUT, (void*)&DB_WRITETIMEOUT);
			bool allow_recnt = true;
			g_db_opers[id]->set_options(MYSQL_OPT_RECONNECT, (void*)&allow_recnt);
			g_db_opers[id]->connect(DB_SERVER.c_str(), DB_USER.c_str(), DB_PASSWORD.c_str(), DB_DATANAME.c_str(), DB_PORT);
		}
		return g_db_opers[id];
	}
	void Common::loadconfig()
	{
		// 装载配置文件
		configure_file ini("eims_server_controler_system.ini");

		MAXTHREADS = ini.read_int("MAXTHREADS");
		HOST_ADDRESS = ini.read_string("HOST_ADDRESS");
		HOST_PORT = ini.read_int("HOST_PORT");

		DB_MAXCONNECTION = ini.read_int("DB_MAXCONNECTION");
		DB_SERVER = ini.read_string("DB_SERVER");
		DB_DATANAME = ini.read_string("DB_DATANAME");
		string str1,str2;
		str1 = ini.read_string("DB_USER");
		str2 = SYSTEM_KEY;
		DB_USER = utility::SES_Decrypt(ini.read_string("DB_USER"), SYSTEM_KEY);

		DB_PASSWORD = utility::SES_Decrypt(ini.read_string("DB_PASSWORD"), SYSTEM_KEY);
		DB_PORT = ini.read_int("DB_PORT");
		DB_MAX_IDLE_TIME = ini.read_int("DB_MAX_IDLE_TIME");
		DB_CONNECTTIMEOUT = ini.read_int("DB_CONNECTTIMEOUT");
		DB_READTIMEOUT = ini.read_int("DB_READTIMEOUT");
		DB_WRITETIMEOUT = ini.read_int("DB_WRITETIMEOUT");

		DEBUG_FILE = ini.read_string("DEBUG_FILE");

		LOGWRITELEVEL = ini.read_int("LOGWRITELEVEL");
		LOGPRINT = ini.read_int("LOGPRINT");
		LOGSUBSCRIBE = ini.read_int("LOGSUBSCRIBE");
		SUBSCRIBEPORT = ini.read_int("SUBSCRIBEPORT");

	}
}
}
