#include "meta.h"

namespace eims
{
namespace meta
{
string get_rand_num(int nlen)
{
	char* code = new char[nlen + 1];
	if(code == NULL)
	{
		return "";
	}
	code[nlen] = '\0';
    char character[11] = "0123456789";

    for (int i = 0; i < nlen; i++)
    {
        code[i] = character[rand() % 10];
    }

    string Result = "";
    Result.append(code);
	delete []code;
    return Result;
}
string get_data_version()
{
	return "";
}

// 获取最新版本流水号(用时间刻度代替的序列)
long long get_data_sequence()
{
	timeval tv;
	gettimeofday(&tv, NULL);

	long long result = (long long)(tv.tv_sec - 1261440000) * (long long)1000000 + tv.tv_usec;

	return result;
}

string get_md5(string src)
{
	return "";
}

string gen_des_key()
{
    string randn = get_rand_num(10);
    string firstmd5 = get_md5(randn);
    string first12chars = firstmd5.substr(0, 12);
    string secondmd5 = get_md5(first12chars);
    string second12chars = secondmd5.substr(0, 12);
    string ret = first12chars + second12chars;
    return ret;
}
stringstream meta_ss;
string longlong2str(long long src)
{
	meta_ss.clear();
	meta_ss<<src;
	string sr = "";
	meta_ss>>sr;
	return sr;
}
long long str2longlong(string src)
{
	meta_ss.clear();
	meta_ss<<src;
	long long sr = 0;
	meta_ss>>sr;
	return sr;
}
bool allisnum(string s)
{
	for(unsigned int i = 0; i < s.length(); i++)
	{
		if ((s.at(i) > '9') || (s.at(i) < '0'))
			return false;
	}
	return true;
}

void resize(char* src, size_t new_size)
{
	if(!src) delete[] src; src = NULL;
	src = new char[new_size];
	memset(src, 0x0, new_size);
	return ;
}

string TimeToString()
{
	time_t t;
	time(&t);

	return TimeToString(t);
}

string TimeToString(const time_t& t)
{
	char s[20];
	strftime(s, sizeof(s), "%Y-%m-%d %H:%M:%S", localtime(&t));
	string result(s);

	return result;
}

unsigned int IPToValue(const string& strIP)
{
	//IP转化为数值
	//没有格式检查
	//返回值就是结果
    int a[4];
    string IP = strIP;
    string strTemp;
    size_t pos;
    size_t i=3;
    do
    {
        pos = IP.find(".");
        if(pos != string::npos)
        {
            strTemp = IP.substr(0,pos);
            a[i] = atoi(strTemp.c_str());
            i--;
            IP.erase(0,pos+1);
        }
        else
        {
            strTemp = IP;
            a[i] = atoi(strTemp.c_str());
            break;
        }
    }while(1);
    unsigned int nResult = (a[3]<<24) + (a[2]<<16)+ (a[1]<<8) + a[0];
    return nResult;
}

string ValueToIP(const unsigned int& nValue)
{
	//数值转化为IP
	//没有格式检查
	//返回值就是结果
    char strTemp[20];
    sprintf( strTemp,"%d.%d.%d.%d",
        (nValue&0xff000000)>>24,
        (nValue&0x00ff0000)>>16,
        (nValue&0x0000ff00)>>8,
        (nValue&0x000000ff) );
    return string(strTemp);
}
}
}
