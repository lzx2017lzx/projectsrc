 #ifndef LOGIC_H
#define LOGIC_H

#include "../frame/protocols/Message.h"
#include "../frame/xml/xml_oper.h"
#include "../frame/common/Common.h"

using namespace eims::db;
using namespace eims::meta;
using namespace eims::common;
using namespace eims::protocols;

class Logic
{
	public:
		Logic();
		virtual ~Logic();

		//获取服务器列表
		void GetBestServer(xml_oper* pxml, mysql_cnt* psql);
};

#endif // LOGIC_H
