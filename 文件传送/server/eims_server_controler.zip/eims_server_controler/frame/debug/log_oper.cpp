#include "log_oper.h"

namespace eims
{
namespace debug
{
Log_Oper::Log_Oper()
{
	m_log = Logger::get_singleton();
}
Log_Oper::~Log_Oper()
{
	;
}
void Log_Oper::WriteLog(char* log, int level)
{
	string strLog(log);
	m_log->write_log(strLog, level);
}
int Log_Oper::GetLevel(char* lev)
{
	//FATAL/ERROR/WARN/DEBUG/INFO/RUNTIME
	string l(lev);
	if(l == "FATAL")
		return eLogLv.FATAL;
	else if(l == "ERROR")
		return eLogLv.ERROR;
	else if(l == "WARN")
		return eLogLv.WARN;
	else if(l == "DEBUG")
		return eLogLv.DEBUG;
	else if(l == "INFO")
		return eLogLv.INFO;
	else
		return eLogLv.RUNTIME;
}
}
}
